# Ratul Volume Control

A native Android media-volume controller with a futuristic dark interface.

## Features
- Futuristic dark UI with cyan/blue accents
- Circular live volume meter
- Direct media-volume slider
- Increase and decrease controls
- Mute / unmute media
- Refreshes the current media volume when the app resumes
- Does not change ringtone, notification, or alarm volume
- No special permissions required

## Build an APK using GitHub Actions
1. Create a GitHub repository.
2. Upload the contents of this project, preserving the folder structure.
3. Open the **Actions** tab.
4. Run **Build Android APK** (or push to `main`).
5. Download the `Ratul-Volume-Control-debug` artifact from the completed workflow.
6. Extract the ZIP to get `app-debug.apk`.

Target SDK: 35. Minimum SDK: 23 (Android 6.0+).
